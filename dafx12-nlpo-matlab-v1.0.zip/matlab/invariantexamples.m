%% Set the parameters

% Design the analog filter (change to your choice)
[b,a] = butter(4,3/4*pi,'s');
% The fundamental frequency of the example
f0 = 3000;
% The sample rate
Fs = 44100;
% The length of the impulse train in samples
len = 2*Fs;
% The pulse width for the rectangular pulse wave
P = 0.25;

% Use Chebychev window
try
    load chebwin.mat,
catch MException,
    win = chebwin(len, 120);
    save chebwin.mat win;
end;
if (length(win) ~= len),
    win = chebwin(len, 120);
    save chebwin.mat win;
end;

%% Generate the triggers for the signal generation

% The basic phasor signal
p = mod((0:len-1)*f0/Fs, 1);
% Pick the discontinuities from the phasor derivative
ds = (filter([1 -1], 1, p, -f0/Fs) < 0);
% The phasor signal for the rectangular pulse wave
pP = mod((0:len-1)*f0/Fs-P, 1);
% Pick the discontinuities for the rectangular pulse wave
dsP = -(filter([1 -1], 1, pP, 0) < 0);

%% Generate the signals

% Transform the analog filter to digital for BLIT generation
[bz1,az1] = impinvar(b, a);
% Transform the analog filter to digital for BLEP generation
[bz2,az2] = impinvar(b,[a 0]);
% The impulse train
imp_train = filter(bz1, az1, ds);
% The rectangular pulse wave
rect_wave = 2*filter(bz2, az2, ds + dsP) - 1;

%% Plots

% Plot the impulse train in time domain
figure; clf;
stem((0:len-1), imp_train, 'fill', 'k');
xlabel('Sample index');
title('Impulse train in time domain, time-invariant method');
axis([0 50 min(imp_train)-0.1 max(imp_train)+0.1]);
% Plot the impulse train in frequency domain
figure; clf;
[h,f] = freqz(imp_train.*win', 1, Fs, Fs); 
plot(f/1000, db(abs(h)), 'k');
xlabel('Frequency (kHz)');
ylabel('Magnitude (dB)');
title('Impulse train in frequency domain, time-invariant method');
axis([0 Fs/2000 max(db(abs(h)))-80 max(db(abs(h)))+5]);
[hx,fx] = freqz(imp_train.*win', 1, (0:(Fs/(2*f0)))*f0, Fs);
hold on;
plot(fx/1000, db(abs(hx)), 'kx', 'markersize', 14);
% Plot the rectangular pulse wave in time domain
figure; clf;
stem((0:len-1), rect_wave, 'fill', 'k');
xlabel('Sample index');
title('Rectangular pulse wave in time domain, time-invariant method');
axis([0 50 min(rect_wave)-0.1 max(rect_wave)+0.1]);
% Plot the rectangular pulse wave in frequency domain
figure; clf;
[h2,f2] = freqz(rect_wave.*win', 1, Fs, Fs); 
plot(f2/1000, db(abs(h2)), 'k');
xlabel('Frequency (kHz)');
ylabel('Magnitude (dB)');
title('Rectangular pulse wave in frequency domain, time-invariant method');
axis([0 Fs/2000 max(db(abs(h)))-80 max(db(abs(h2)))+5]);
[hx2,fx2] = freqz(rect_wave.*win', 1, (0:(Fs/(2*f0)))*f0, Fs);
hold on;
plot(fx2/1000, db(abs(hx2)), 'kx', 'markersize', 14);
