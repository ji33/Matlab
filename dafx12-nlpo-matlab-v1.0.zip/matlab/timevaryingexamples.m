%% Set the parameters

% Design the analog filter (change to your choice)
[b,a] = ellip(5, 1, 81, 3/4*pi, 's');
% The fundamental frequency of the example
f0 = 3000;
% The sample rate
Fs = 44100;
% The length of the impulse train in samples
len = 2*Fs;
% The pulse width for the rectangular pulse wave
P = 0.25;
% Polynomial approximation order (set to 0 if you want to use exact method)
N = 0;

% Use Chebychev window
try
    load chebwin.mat,
catch MException,
    win = chebwin(len, 120);
    save chebwin.mat win;
end;
if (length(win) ~= len),
    win = chebwin(len, 120);
    save chebwin.mat win;
end;

%% Generate the impulse train, and plot it and its spectrum

% Generate the waveform
num_pulses = ceil(len/(Fs/f0));
blit = nlpo(Fs/f0*(0:num_pulses), ones(1,num_pulses+1), b, a, N);
blit = blit(1:len)';
% Plot the impulse train
figure; clf;
stem(0:len-1, blit, 'fill', 'k');
xlabel('Sample index');
title('Impulse train in time domain, time-varying method');
axis([0 50 min(blit)-0.1 max(blit)+0.1]);
% Compute the spectrum
[BLIT, f] = freqz(blit.*win, 1, Fs, Fs);
% Plot the spectrum
figure; clf
plot(f/1000, db(abs(BLIT)), 'k');
xlabel('Frequency (kHz)');
ylabel('Magnitude (dB)');
title('Impulse train in frequency domain, time-varying method');
axis([0 Fs/2000 max(db(abs(BLIT)))-70 max(db(abs(BLIT)))+5]);
[BLIT2, f2] = freqz(blit.*win, 1, (0:(Fs/(2*f0)))*f0, Fs);
hold on;
plot(f2/1000, db(abs(BLIT2)), 'kx', 'markersize', 14);

%% Generate the rectangular pulse waveform, and plot it and its spectrum

% Generate the waveform
num_pulses = ceil(len/(Fs/f0));
blep = nlpo([Fs/f0*(0:num_pulses) Fs/f0*((0:num_pulses)+P)], [1 2*ones(1,num_pulses) -2*ones(1,num_pulses+1)], b, [a 0], N);
blep = blep(1:len)';
% Plot the impulse train
figure; clf;
stem(0:len-1, blep, 'fill', 'k');
xlabel('Sample index');
title('Rectangular pulse wave in time domain, time-varying method');
axis([0 50 min(blep)-0.1 max(blep)+0.1]);
% Compute the spectrum
[BLEP,f2] = freqz(blep.*win,1,Fs,Fs);
% Plot the spectrum
figure; clf;
plot(f2/1000,db(abs(BLEP)),'k');
xlabel('Frequency (kHz)');
ylabel('Magnitude (dB)');
title('Rectangular pulse wave in frequency domain, time-varying method');
axis([0 Fs/2000 max(db(abs(BLEP)))-70 max(db(abs(BLEP)))+5]);
[BLEP2, f2] = freqz(blep.*win, 1, (0:(Fs/(2*f0)))*f0, Fs);
hold on;
plot(f2/1000, db(abs(BLEP2)), 'kx', 'markersize', 14);
