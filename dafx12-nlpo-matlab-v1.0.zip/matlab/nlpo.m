function [y, b, a] = nlpo (tpnorm, varargin)
% [y, b, a] = nlpo (tpnorm)
%   generates an impulse train with the impulses at times given in tpnorm using
%   an approximation using IIR filters. The times are measured in samples, but
%   may be fractional. The resulting impulse train is stored in y, the
%   coefficients of the prototype lowpass in b and a.
% [y, b, a] = nlpo (tpnorm, ampl)
%   generates an impulse train with the impulses at times given in tpnorm using
%   an approximation using IIR filters. The times are measured in samples, but
%   may be fractional. Each pulse is weighted with the corresponding value in
%   ampl; ampl and tpnorm must be of same length. The resulting impulse train
%   is stored in y, the coefficients of the prototype lowpass in b and a.
% [y] = nlpo (tpnorm, ampl, b, a)
%   works as above but allows to specify the prototype lowpass. Note that the
%   lowpass must not contain non-simple poles and the numerator order must be
%   lower than the denominator order.
% [y, a, b] = nlpo (..., approxorder)
%   specifies the polynomial order used for approximation of the driving
%   signals. Choosing 0 turns off approximation, instead evaluating the true
%   complex eponential functions.
% [y, a, b] = nlpo (..., 'rect')
%   generates a rect instead of an impulse wave as if the usually generated
%   impulse train had been integrated
%
% Author: M. Holters <martin.holters@hsu-hh.de>

userect = 0;
if nargin > 1 && ischar(varargin{nargin-1})
    if strcmp(varargin{nargin-1}, 'rect')
        userect = 1;
    else
        error('"%s" is not a valid type', varargin{nargin-1});
    end
end

if nargin < 5 + userect
    if nargin == 1 + userect % called with (tpnorm)
        ampl = ones(size(tpnorm));
        approxorder = 3;
    end;
    if nargin == 2 + userect
        if isscalar(varargin{1}) && length(tpnorm)~=1 % called with (tpnorm, approxorder)
            approxorder = varargin{1};
            ampl = ones(size(tpnorm));
        else % called with (tpnorm, ampl)
            ampl = varargin{1};
            approxorder = 3;
        end
    end;
    if nargin == 3 + userect % called with (tpnorm, ampl, approxorder)
        ampl = varargin{1};
        approxorder = varargin{2};
    end
    if nargin == 4 + userect
        if length(tpnorm) == length(varargin{1}) % called with (tpnorm, ampl, b, a)
            ampl = varargin{1};
            b = varargin{2};
            a = varargin{3};
            approxorder = 3;
        else % called with (tpnorm, b, a, approxorder)
            b = varargin{1};
            a = varargin{2};
            approxorder = varargin{3};
            ampl = ones(size(tpnorm));
        end
    end
else
    ampl = varargin{1};
    b = varargin{2};
    a = varargin{3};
	approxorder = varargin{4};
end;

if nargin < 4 + userect
	% generate prototype lowpass
	[b,a] = ellip(5, 1, 81, 3*pi/4, 's');
end;

tpnorm=tpnorm(:);
ampl=ampl(:);

[r,p,g]=residue(b,a);  % decompose

assert(isempty(g), 'order of numerator has to be lower than order of denominator')
assert(length(unique(p))==length(p), 'only simple poles supported')

[pc, rc, pr, rr] = splitsections(p, r);  % split into conjugate complex and real sections

np = ceil(tpnorm);            % sampling points following the pulses
taupnorm = tpnorm - (np - 1); % normalized to ]0, 1]
len = np(end) + np(end) - np(end-1);

if userect == 1
	rr = rr ./ pr;
    rc = rc ./ pc;
end

y = zeros(1,len);
u = zeros(1,len);

for k=1:length(pr)  % for each real first order section
	pole=exp(pr(k));
	if approxorder
		polycoeff = polyfit(linspace(0,1), (pole*rr(k)*pole.^(-linspace(0,1))), approxorder);
		u(np+1) = ampl.*polyval(polycoeff, taupnorm); % generate excitation
	else
		u(np+1) = ampl.*pole.*rr(k).*pole.^(-taupnorm);  % generate excitation
	end;
	y=y+filter(1, [1, -pole], u); % filter and add to output
end;
if userect == 1
    u(np + 1) = ampl;
    y=y+filter(1, [1, -1], u);
end

for k=1:length(pc)  % for each complex cunjugate first order section
	pole=exp(pc(k));
	if approxorder
		polycoeff1 = polyfit(linspace(0,1), 2*real(pole.^-linspace(0,1)*rc(k)*pole), approxorder);
		polycoeff2 = polyfit(linspace(0,1), (-2*real(pole.^-linspace(0,1)*rc(k))*abs(pole)^2), approxorder);
		u(np+1) = ampl.*polyval(polycoeff1, taupnorm); % generate excitation
		u(np+2) = ampl.*polyval(polycoeff2, taupnorm); % generate excitation
	else
		u(np+1) = ampl.*2.*real(pole.^-taupnorm*rc(k)*pole);
		u(np+2) = ampl.*-2.*real(pole.^-taupnorm*rc(k)).*abs(pole)^2;
	end;
	y=y+filter(1, [1, -2*real(pole), abs(pole)^2], u); % filter and add to output
end;

function [pc, rc, pr, rr] = splitsections(p, r)
pc=[];
rc=[];
pr=[];
rr=[];
while length(p) >= 2
	[val, idx] = min(abs(p(1) - conj(p(2:end))) + abs(r(1) - conj(r(2:end))));
	idx = idx + 1;
	if (val > abs(imag(p(1))) + abs(imag(r(1)))) % real
		pr = [pr; real(p(1))];
		p = p(2:end);
		rr = [rr; real(r(1))];
		r = r(2:end);
	else % complex conjugate
		pc = [pc; p(1)];
		p = [p(2:idx-1); p(idx+1:end)];
		rc = [rc; r(1)];
		r = [r(2:idx-1); r(idx+1:end)];
	end;
end;

if length(p) >= 1
	pr = [pr; real(p(1))];
	rr = [rr; real(r(1))];
end;
